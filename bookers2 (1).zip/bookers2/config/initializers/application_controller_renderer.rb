# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f4ef851ebf8f107636667d24fcba8966bf59be4a257a803da407ea1b500dd22f5535cda4b9ab8a03b29d5c74abab3d7681a4d7924388671d3fe505509f02946b'
