class Book < ApplicationRecord
  belongs_to :user
  self.ignored_columns = [:opinion]
  
  validates :title, presence: true
  validates :body, presence: true, length: {maximum: 200}
end
