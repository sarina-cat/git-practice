Rails.application.routes.draw do
  devise_for :users
  root 'homes#top'
  get 'home/about', to: 'homes#about'
    resources :books, only: [:create, :edit, :index, :show, :destroy, :update]
    resources :users, only: [:index, :show, :create, :edit, :update, :destroy]
    post 'books/:id' => 'books#show'
end